type coordinates={
    lat:number,
    lon:number,

}


export type optionType={
    name:string,
    coordinates:coordinates,
    cou_name_en:string,
    timezone:string

}